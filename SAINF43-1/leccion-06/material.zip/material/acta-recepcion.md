# Acta de recepción - Caso CSA-2026-044

**Organización:** COSTA AZUL SPA (caso ficticio).  
**Fecha de recepción:** 2026-09-14 08:20 America/Santiago.  
**Pregunta de esta etapa:** ¿qué fuentes deben preservarse primero y bajo qué condiciones pueden aceptarse para un análisis posterior?

## Antecedente

El 14 de septiembre, a las 07:48, el equipo de monitoreo informó actividad administrativa no esperada asociada al servidor Windows `WIN10-CASO01`. Al momento de la notificación permanecían activos el servidor, el sensor de red y la sesión del servicio SaaS corporativo. Todavía no existe una conclusión sobre el origen ni la intención de la actividad.

## Alcance autorizado para la Lección 06

Se autoriza al equipo de análisis a:

- inventariar las fuentes descritas en `inventario-fuentes.csv`;
- verificar los archivos ya entregados contra `manifest_entrega.sha256`;
- revisar tipo, tamaño, fechas del sistema de archivos y cabeceras técnicas del correo;
- clasificar riesgos, proponer prioridad y redactar un plan de preservación;
- identificar acciones que requieren autorización o competencia adicional.

## Acciones no autorizadas en esta etapa

- Adquirir memoria RAM, detener servicios, apagar o reiniciar equipos.
- Acceder a la cuenta SaaS o solicitar una exportación nueva en nombre de la organización.
- Montar, descifrar o examinar el disco de `WIN10-CASO01`.
- Leer el cuerpo completo del correo o los registros de clientes del respaldo.
- Corregir, reemplazar o volver a generar el manifiesto recibido.

Las acciones anteriores deben formularse como recomendaciones condicionadas. Si una fuente presenta una discrepancia, el equipo debe detener su examen, conservar el resultado y escalar la decisión.

## Material recibido

- Un inventario de seis fuentes potenciales.
- Cuatro archivos técnicos ya exportados en la carpeta `exportados/`.
- Un manifiesto SHA-256 entregado por el custodio.

**Custodio que entrega:** Mesa de respuesta a incidentes de COSTA AZUL SPA.  
**Custodio que recibe:** Equipo de análisis de la Lección 06.
