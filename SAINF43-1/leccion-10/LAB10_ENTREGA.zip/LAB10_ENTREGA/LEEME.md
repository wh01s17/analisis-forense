---
title: "Entrega estudiantil Lección 10 - CLOUD-MOVIL-CASO04"
course: INF43 - Análisis Forense
lesson: "10"
---

# Entrega estudiantil Lección 10 - CLOUD-MOVIL-CASO04

Abre `documentos/actividad-leccion-10.md`. Contiene el caso, los comandos, las tablas y la forma de respaldar la bitácora. Si un comando falla o necesitas comprenderlo, consulta `documentos/guia-comandos-leccion-10.md`.

| Carpeta | Contenido |
| --- | --- |
| `documentos/` | Actividad y guía de comandos. |
| `evidencia/` | Exportación SaaS, identidad, MDM, proxy, objeto XLSX y adquisición lógica móvil SQLite. |
| `notas/` | Manifiesto SHA-256, ficha técnica y comprobante de preservación. |

Trabaja con `LAB10_ENTREGA` montada en solo lectura y guarda la bitácora en una carpeta distinta con escritura. Si el manifiesto muestra `FAILED` o la evidencia admite escritura, detén el procedimiento y avisa al docente.

No abras `costos-2027.xlsx` con una aplicación de oficina. En esta práctica solo se identifica su tipo, se comprueba su estructura y se calcula su SHA-256.
