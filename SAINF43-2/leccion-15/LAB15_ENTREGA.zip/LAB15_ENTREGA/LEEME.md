---
title: "Entrega estudiantil Lección 15 - AR-CASO06 (correo y web)"
course: INF43 - Análisis Forense
lesson: "15"
---

# Entrega estudiantil Lección 15 - AR-CASO06 (correo y web)

Abre `documentos/actividad-leccion-15.docx` y guarda una copia en una ubicación con escritura del anfitrión. Incluye el caso, las instrucciones y los espacios para responder. Los comandos se consultan en la guía de apoyo; se usan ripMIME y herramientas básicas de Linux. Completen y entreguen únicamente ese DOCX, uno por pareja, con la revisión y las correcciones incorporadas. El PDF de la actividad es de consulta. Las guías de lectura y de comandos se descargan por separado desde el aula virtual.

| Carpeta | Contenido |
| --- | --- |
| `documentos/` | Actividad editable en DOCX y su versión de consulta en PDF. |
| `caso/` | Solicitud de la jefatura y autorización. |
| `evidencia/` | Dos correos, registro del proxy y dos registros del portal. |
| `notas/` | Ficha técnica, manifiesto SHA-256, documentos del portal, antecedentes de L13 y L14 y extracto de ATT&CK. |

**Seguridad.** No visites los enlaces, dominios o IP del caso ni los consultes en servicios en línea. El adjunto del correo es la muestra inerte de la lección 13: se extrae para calcular su hash y su tipo, pero **no se abre ni se ejecuta**.
