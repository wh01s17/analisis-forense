---
title: "Plantilla de bitácora Lección 08 - RED-CASO02"
course: INF43 - Análisis Forense
lesson: "08"
---

# Bitácora Lección 08 - RED-CASO02

## Identificación

| Dato | Registro |
| --- | --- |
| Integrantes y rol inicial | [Completar] |
| Sección | [Completar] |
| Fecha | [Completar] |
| Zona horaria de Kali | [Completar] |
| Zona horaria del caso | [Completar] |
| Versión de `tshark` | [Completar] |

## 1. Control de la evidencia

| Control | Resultado | Evidencia breve |
| --- | --- | --- |
| `LAB08_ENTREGA` rechaza la escritura | [Sí / No] | [Mensaje de la prueba de escritura] |
| SHA-256 de `RED-CASO02.pcap` | [OK / discrepancia] | [Completar] |
| IP y equipo investigados | [Completar] | [Archivo `.env`] |
| Punto de captura | [Completar] | [Ficha técnica] |
| Dos limitaciones declaradas por TI | [Completar] | [Ficha técnica] |

## 2. Panorama de la captura

| Dato | Registro |
| --- | --- |
| Paquetes | [ ] |
| Primer paquete (UTC y hora local) | [ ] |
| Último paquete (UTC y hora local) | [ ] |
| Protocolos presentes | [ ] |
| Conversaciones de `10.8.20.45` | [ ] |
| Conversación externa con más paquetes | [ ] |

## 3. Filtros reproducibles

| # | Pregunta | Filtro usado | Paquetes |
| ---: | --- | --- | ---: |
| 1 | Respuestas DNS recibidas por el equipo investigado | [ ] | [ ] |
| 2 | Solicitudes HTTP de la captura | [ ] | [ ] |
| 3 | Respuestas HTTP con error | [ ] | [ ] |
| 4 | `Client Hello` enviados por el equipo investigado | [ ] | [ ] |

## 4. Sesión HTTP reconstruida

`tcp.stream` de la sesión: [ ]

| Fila | Paso | Paquete | Hora UTC | Hora local | Origen:puerto | Destino:puerto | Protocolo | Dato observado |
| ---: | --- | ---: | --- | --- | --- | --- | --- | --- |
| 1 | Consulta DNS | [ ] | [ ] | [ ] | [ ] | [ ] | DNS | [ ] |
| 2 | Respuesta DNS | [ ] | [ ] | [ ] | [ ] | [ ] | DNS | [ ] |
| 3 | Apertura TCP (`SYN`) | [ ] | [ ] | [ ] | [ ] | [ ] | TCP | [ ] |
| 4 | Aceptación (`SYN, ACK`) | [ ] | [ ] | [ ] | [ ] | [ ] | TCP | [ ] |
| 5 | Primera solicitud | [ ] | [ ] | [ ] | [ ] | [ ] | HTTP | [ ] |
| 6 | Primera respuesta | [ ] | [ ] | [ ] | [ ] | [ ] | HTTP | [ ] |
| 7 | Segunda solicitud | [ ] | [ ] | [ ] | [ ] | [ ] | HTTP | [ ] |
| 8 | Segunda respuesta | [ ] | [ ] | [ ] | [ ] | [ ] | HTTP | [ ] |

```text
Qué indica el User-Agent y por qué no basta para afirmar qué programa lo envió:

Nombre de archivo y tipo de contenido declarados por el servidor:
```

## 5. Objeto extraído

| Dato | Registro |
| --- | --- |
| Nombre del objeto | [ ] |
| Paquete de la respuesta que lo contiene | [ ] |
| Tamaño en bytes y `Content-Length` | [ ] |
| SHA-256 | [ ] |
| Otros objetos exportados y su origen | [ ] |
| Qué describe el contenido (leído en el stream TCP) | [ ] |

- [ ] No abrí el archivo exportado con una aplicación asociada ni lo ejecuté.

## 6. Serie de conexiones TLS

| Paquete | Hora UTC | `tcp.stream` | Destino | SNI | Intervalo con el anterior (s) |
| ---: | --- | ---: | --- | --- | ---: |
| [ ] | [ ] | [ ] | [ ] | [ ] | - |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

### Correlación entre la descarga y la serie TLS

```text
Evidencia A:
Evidencia B:
Campo o dato de unión:
Relación observada:
Inferencia:
Confianza:
Explicación alternativa o dato faltante:
```

## 7. Indicadores

Escribe dominios y URL neutralizados: `ejemplo[.]invalid`, `hxxp://`.

| Indicador | Tipo | Paquetes | Ventana UTC | Por qué interesa | Posible uso legítimo o falso positivo |
| --- | --- | --- | --- | --- | --- |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 8. Conclusión

Entre 80 y 100 palabras. Distingue hecho observado, inferencia y límite:

> [Completar]

## 9. Limitaciones

- [Lo que el cifrado impide ver].
- [Lo que la captura no puede mostrar sobre el equipo o la persona].
- [Otra limitación del punto de captura, del tiempo o de la cobertura].

## Ampliación

```text
Ampliación realizada:

Desarrollo:
```

## Comprobación de entrega

- [ ] Registré la hora UTC y la hora local en cada fila de la sesión.
- [ ] Cada afirmación cita un número de paquete o un filtro.
- [ ] Los cuatro filtros están escritos tal como los ejecuté.
- [ ] Separé hechos, inferencias y limitaciones.
- [ ] Neutralicé dominios y URL en la sección de indicadores.
- [ ] Copié esta bitácora a `LAB08_SALIDA` y comprobé que ambas copias coincidían.
- [ ] Entregué o respaldé esta bitácora desde Windows antes de apagar el PC.
