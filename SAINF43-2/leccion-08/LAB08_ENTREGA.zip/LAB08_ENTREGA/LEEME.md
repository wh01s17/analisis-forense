---
title: "Entrega estudiantil Lección 08 - RED-CASO02"
course: INF43 - Análisis Forense
lesson: "08"
---

# Entrega estudiantil Lección 08 - RED-CASO02

## Contenido

- `documentos/actividad-leccion-08.md`: instrucciones y producto evaluado.
- `documentos/guia-de-lectura-leccion-08.md`: preparación conceptual y consulta.
- `documentos/guia-comandos-leccion-08.md`: procedimiento técnico paso a paso con `tshark`.
- `documentos/plantilla-bitacora-leccion-08.md`: archivo editable para registrar y entregar el trabajo.
- `documentos/handshakes-tcp-tls.svg`: diagrama que muestra la guía de lectura; mantenlo en la misma carpeta que el `.md`.
- `documentos/*.pdf`: versiones en PDF para leer en Windows, cuando el docente las incluya. Los comandos se copian igual desde el PDF o desde el `.md`.
- `evidencia/RED-CASO02.pcap`: captura de red del caso.
- `notas/RED-CASO02.sha256`: manifiesto para comprobar la captura.
- `notas/RED-CASO02-captura.txt`: ficha técnica, inventario de TI y limitaciones declaradas.
- `notas/RED-CASO02-caso.env`: parámetros confirmados del caso.

## Antes de comenzar

Cada pareja recibe `LAB08_ENTREGA` mediante un pendrive o el aula virtual. Copia la carpeta completa al disco del PC anfitrión antes de abrir Kali; no trabajes directamente desde el pendrive. El paquete ocupa menos de 1 MB.

En VirtualBox configura dos carpetas compartidas, igual que en la Lección 07:

| Nombre | Contenido | Acceso desde Kali |
| --- | --- | --- |
| `LAB08_ENTREGA` | Copia del paquete en el anfitrión | Solo lectura y montaje automático |
| `LAB08_SALIDA` | Carpeta vacía para recuperar la bitácora | Lectura y escritura, con montaje automático |

La ruta esperada de la captura en Kali es `/media/sf_LAB08_ENTREGA/evidencia/RED-CASO02.pcap`. Los archivos de trabajo, los objetos exportados y la bitácora se guardan en `~/forense/LAB-08/`; al terminar, copia únicamente la bitácora a `/media/sf_LAB08_SALIDA/`. Los PC del laboratorio se restablecen al reiniciarse: lo que quede en el disco del anfitrión, incluida la carpeta `LAB08_SALIDA`, se pierde al apagarlo. Antes de apagar, entrega o respalda la bitácora desde Windows por el medio que indique el docente.

Confirma con el docente que:

- Kali conserva o restaura el estado seguro `LAB-03-configurado`;
- `tshark` y `capinfos` están disponibles o pueden instalarse antes de aislar la red;
- `/media/sf_LAB08_ENTREGA/` existe y rechaza la escritura (VirtualBox con la opción Solo lectura);
- `/media/sf_LAB08_SALIDA/` existe y admite escritura.

## Orden de uso

1. Revisa la guía de lectura antes de la clase.
2. Copia este paquete al PC anfitrión y configura las dos carpetas compartidas.
3. Abre la actividad y usa la guía de comandos como referencia durante el laboratorio.
4. Comprueba el manifiesto antes de analizar la captura.
5. Analiza la captura sin resolución de nombres y guarda los archivos de trabajo en `~/forense/LAB-08/`.
6. Copia únicamente la bitácora terminada a `LAB08_SALIDA` y, desde Windows, entrégala o respáldala antes de apagar el PC. No entregues la captura ni los objetos exportados.

## Regla de seguridad

Si la carpeta de evidencia admite escritura o el hash muestra `FAILED`, detén el procedimiento e informa al docente. No visites los dominios ni las direcciones de la captura, no ejecutes ni abras los objetos exportados y no los subas a servicios públicos de análisis.
