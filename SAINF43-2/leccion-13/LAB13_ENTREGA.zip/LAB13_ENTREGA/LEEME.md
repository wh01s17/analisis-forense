---
title: "Entrega estudiantil Lección 13 - AR-CASO06"
course: INF43 - Análisis Forense
lesson: "13"
---

# Entrega estudiantil Lección 13 - AR-CASO06

Abre `documentos/actividad-leccion-13.md`. Contiene el caso, la ficha de análisis estático y el registro de recuperación autorizada. La actividad indica cómo copiarla a tu carpeta de trabajo para completarla: ese archivo es tu entrega. Si un comando falla o necesitas comprender su propósito, consulta `documentos/guia-comandos-leccion-13.md`.

| Carpeta | Contenido |
| --- | --- |
| `documentos/` | Actividad y guía de comandos. |
| `caso/` | Autorización y lista acotada de candidatos. |
| `muestra/` | Muestra inerte para análisis estático. **No la ejecutes.** |
| `recuperacion/` | Contenedor protegido para la recuperación autorizada. |
| `notas/` | Ficha técnica, manifiesto SHA-256 y referencia local de ATT&CK (la estación no tiene red). |

**Seguridad.** La muestra es material inerte de laboratorio: no debe ejecutarse, abrirse con doble clic ni subirse a servicios en línea. Trabaja en la estación aislada. Para recuperar el contenedor usa únicamente la lista de `caso/candidatos-autorizados.txt`. Si un hash no coincide, el contenido es inesperado o la lista se agota sin resultado, detén el procedimiento y avisa al docente.
