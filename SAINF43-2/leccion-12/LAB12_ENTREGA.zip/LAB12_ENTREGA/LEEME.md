---
title: "Entrega estudiantil Lección 12 - NS-CASO05"
course: INF43 - Análisis Forense
lesson: "12"
---

# Entrega estudiantil Lección 12 - NS-CASO05

Abre `documentos/actividad-leccion-12.md`. Contiene el caso, las tablas de trabajo y la forma de respaldar la bitácora, las salidas y sus hashes. Si un comando falla o necesitas comprender su propósito, consulta `documentos/guia-comandos-leccion-12.md`.

| Carpeta | Contenido |
| --- | --- |
| `documentos/` | Actividad y guía de comandos. |
| `caso/` | Solicitud de gerencia, autorización, inventario preliminar y cadena de custodia recibida. |
| `evidencia/` | Exportaciones VPN, auditoría cloud y metadatos de correo. |
| `notas/` | Manifiesto SHA-256 y ficha técnica de las exportaciones. |

Trabaja con `LAB12_ENTREGA` montada en solo lectura y guarda la bitácora, las verificaciones, las salidas y los anexos en una carpeta distinta. Si el manifiesto muestra `FAILED` o el paquete no está en solo lectura, detén el procedimiento y avisa al docente.

El inventario y la cadena de custodia recibidos contienen errores a propósito: corrígelos en tu bitácora, no en estos archivos.
