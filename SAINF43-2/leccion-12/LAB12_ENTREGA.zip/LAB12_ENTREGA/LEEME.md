---
title: "Entrega estudiantil Lección 12 - NS-CASO05"
course: INF43 - Análisis Forense
lesson: "12"
---

# Entrega estudiantil Lección 12 - NS-CASO05

Abre `documentos/actividad-leccion-12.md`. Contiene el caso, los comandos, las tablas y la forma de respaldar la bitácora y la cadena de custodia. Si un comando falla o necesitas comprenderlo, consulta `documentos/guia-comandos-leccion-12.md`.

| Carpeta | Contenido |
| --- | --- |
| `documentos/` | Actividad y guía de comandos. |
| `caso/` | Solicitud de gerencia, autorización, inventario preliminar y cadena de custodia recibida. |
| `evidencia/` | Exportaciones VPN, auditoría cloud y metadatos de correo. |
| `notas/` | Manifiesto SHA-256 y ficha técnica de las exportaciones. |

Trabaja con `LAB12_ENTREGA` montada en solo lectura y guarda la bitácora, la custodia y las salidas en una carpeta distinta. Si el manifiesto muestra `FAILED` o la evidencia admite escritura, detén el procedimiento y avisa al docente.

El inventario y la cadena de custodia recibidos contienen errores a propósito: corrígelos en tu bitácora, no en estos archivos.
