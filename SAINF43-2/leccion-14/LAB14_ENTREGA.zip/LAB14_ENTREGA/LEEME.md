---
title: "Entrega estudiantil Lección 14 - AR-CASO06 (fase dinámica)"
course: INF43 - Análisis Forense
lesson: "14"
---

# Entrega estudiantil Lección 14 - AR-CASO06 (fase dinámica)

Sigue la actividad que entrega el docente; las respuestas y capturas van en la plantilla de entrega.

| Carpeta | Contenido |
| --- | --- |
| `documentos/` | Actividad y guía de comandos. |
| `caso/` | Autorización de la ejecución controlada. |
| `muestra/` | Muestra didáctica en un ZIP con contraseña `infected` y su manifiesto SHA-256. |
| `notas/` | Ficha técnica, predicciones de la lección 13 y referencia local de ATT&CK. |
| `respaldo/` | Evidencia grabada por el docente, solo si tu máquina de análisis falla. |

**Seguridad.** La muestra se extrae y se ejecuta **solo en WIN-10-L14**, conectada únicamente a la red `lab_malware`, después de restaurar el snapshot `LAB-L14`. No la extraigas en Kali ni en el computador anfitrión y no la subas a servicios en línea.
