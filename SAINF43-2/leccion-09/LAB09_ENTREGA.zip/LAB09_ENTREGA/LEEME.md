---
title: "Entrega estudiantil Lección 09 - BD-CASO03"
course: INF43 - Análisis Forense
lesson: "09"
---

# Entrega estudiantil Lección 09 - BD-CASO03

Abre **`documentos/actividad-leccion-09.md`** (o su PDF). Contiene todo lo necesario: el caso, los datos entregados por TI, la preparación de las carpetas compartidas, los comandos, las tablas y la entrega. Para trabajar basta con ese archivo. Si un comando falla o quieres entender qué hace, consulta `documentos/guia-comandos-leccion-09.md` (o su PDF): explica cada comando, cómo leer su salida y qué hacer ante cada error.

| Carpeta | Contenido |
| --- | --- |
| `documentos/` | La actividad, que también es la bitácora; la guía de comandos de apoyo; y sus copias en PDF. |
| `evidencia/` | `app-erp.log`, `postgresql.log` y `BD-CASO03.sqlite`. Se analizan solo desde Kali, en modo de lectura. |
| `notas/` | Manifiesto SHA-256 y ficha técnica original de TI. Los comandos de la actividad los usan; no hace falta abrirlos. |

Si la carpeta de evidencia admite escritura o el manifiesto muestra `FAILED`, detén el procedimiento e informa al docente.
